[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/8f3eLi1T)
- [Setup](#org8e652d4)



<a id="org8e652d4"></a>

# Setup

-   `git clone` this to `~`, or a directory you see fit.
-   If you want to use your MSP432:
    -   Import the repository into CCS as a CCS project.
    -   **DEBUG** the project and press the green play button.
-   You can also use a C compiler, online or on your own device
    -   `clang main.c && ./a.out`