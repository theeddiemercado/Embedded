// F25 Homework 1 - Converter Tool
// TODO: Write name below and delete this line.
// Name:Eddie Mercado
//
// This program is a converter tool that helps you with your homework.
// It should convert the scenarios in Problems 3, 4, and 5.
//
// Problem 1.1: Convert decimal to 8-bit unsigned binary, add leading 0s
// Problem 1.2: Convert decimal to 2-digit hexadecimal
//
// Problem 2: Convert decimal to 8-bit signed 2's complement binary, add leading
// 0s
//
// Problem 3: Convert 8-bit signed 2's complement binary to decimal
//
// The program should ask the user to enter a decimal or 8-bit signed 2's
// complement binary number and ask the user to choose the conversion type.
// The program should then print the result.
//
// Author: Hao Xiang Liew
// Edited by: Kristopher DeGray 8/28/2024
// Edited by: Anson Trapani 1/22/2025
// Edited by: Aiden Wiehn 8/29/2025

// Development notes:
// 1. There is no need to add any #includes
// 2. The function definitions, helper functions, and the main function are
//    complete. There is no need to modify them or add any new functions.
// 3. Only need to fill in the places marked with // TODO
// 4. Think about how you did conversions by hand and translate it into code,
//    create a sample rudimentary algorithm, then optimize it with C logic.
// 5. Learn basic C here: https://www.w3schools.com/c/

#include <stdio.h>

void reverseString(char *str, int length)
{
  int start = 0;
  int end = length - 1;
  while (start < end)
  {
    char temp = str[start];
    str[start] = str[end];
    str[end] = temp;
    start++;
    end--;
  }
}

int decimalToBinary(int decimal, char *binary)
{
  // Problem 1.1
  // TODO: check if the input is outside of the range of 8-bit unsigned binary
  //          if so, return 1;


if(decimal < 0 || decimal > 255) return 1;

  // TODO: Convert decimal to 8-bit unsigned binary, add leading 0s
int i;
for(i = 7; i >= 0; --i){
    binary[7 - i] = ((decimal >> i) & 1) ? '1' : '0';
}

  binary[8] = '\0';
  return 0;
}

int decimalToHex(int decimal, char *hex)
{
  // Problem 1.2

  // TODO: check if the input is outside of the range of 2-digit hexadecimal
  //          if so, return 1;

if(decimal < 0 || decimal > 255) return 1;

  // TODO: Convert decimal to 2-digit hexadecimal
  // Hint: The reverseString function might be useful

sprintf(hex, "%02X", decimal);               //sprintf() takes the format string and the provided arguments,
                                            //applies the specified formatting rules, and writes the resulting characters into a string
                                            //% specifies data type, 0 pads leading zeros, 2 for @ least 2 digits, X for hex digits


  hex[2] = '\0';
  return 0;
}

int decimalToTwosComplement(int decimal, char *binary)
{
  // Problem 2

  // TODO: check if the input is outside of the range of 8-bit signed 2's complement binary
  //          if so, return 1;

    if(decimal < -128 || decimal > 127) return 1;

  // TODO: Convert decimal to 8-bit signed 2's complement binary, add leading 0s

unsigned int u = (unsigned int)(decimal & 0xFF);                     //unsigned int is a data type used to declare integer variables that can only store non-negative values
                                                                    //decimal & 0xFF keeps the lower 8 bits casting to unsigned integer to safely shift the bits
int i;

for(i = 7; i >= 0; --i){
    binary[7 - i] = ((decimal >> i) & 1) ? '1' : '0';
}                                                      // for loop cycles through 8 bits from MSB to LSB
                                                       // ? '1' : '0' converts each bit to a 1 or 0
                                                       // binary[7 - i] stores bit in proper place

  binary[8] = '\0';
  return 0;
}

int twosComplementToDecimal(int binary, char *decimalOut)
{
  // Problem 3

  // TODO: check if the input is not 8 bits or is not binary
  //          if so, return 1;

int x = binary;                                                    //If zero is entered, initialize a count
int count = 0;
if(x == 0) count = 1;

while(x > 0){
    int number = x % 10;                                            //x % 10 extracts last digit
    if(number != 0 && number != 1) return 1;                       // Error if not a 1 or 0
    x /= 10;                                                      // divide x by 10 and assign to x
    count++;
}

if(count == 0 || count > 8) return 1;                             //Error if count is zero or greater than 8


  // TODO: Convert 8-bit signed 2's complement binary to decimal, add leading 0s

unsigned int value = 0;                                          //Initialize value, position
unsigned int position = 0;
x = binary;

while(position < 8) {                                           //Loop for the position of the digit
    unsigned int bit = (unsigned int)(x % 10);                  //unsigned int is a data type used to declare integer variables that can only store non-negative values
    value |= (bit << position);
    x /= 10;
    position++;

}

int decimal = (value & 0x80) ? (int) value - 256 : (int) value;         //Views the 8 bit # as a signed 2's complement
                                                                        //0x80 is the highest signed bit
                                                                        //Subtract 256 from signed bit to get negative value


        sprintf(decimalOut, "%d", decimal); // this function converts an integer to a character array
  return 0;
}

int main()
{
  int choice, decimal, binary;
  char tempString[9];
  printf("Enter a decimal or 8-bit signed 2's complement binary number: ");
  scanf("%d", &decimal);
  printf("Enter the conversion type:\n");
  printf("1. Decimal to 8-bit unsigned binary\n");
  printf("2. Decimal to 2-digit hexadecimal\n");
  printf("3. Decimal to 8-bit signed 2's complement binary\n");
  printf("4. 8-bit signed 2's complement binary to decimal\n");
  printf("Enter your choice: ");
  scanf("%d", &choice);
  switch (choice)
  {
  case 1:

    if (decimalToBinary(decimal, tempString))
    {

      printf("Overflow error: input is outside the range of an 8-bit unsigned "
             "integer.\n");
    }
    else
    {
      printf("The result is %s\n", tempString);
    }
    break;
  case 2:
    if (decimalToHex(decimal, tempString))
    {
      printf("Overflow error: input is outside the range of 2-digit hex\n");
    }
    else
    {
      printf("The result is %s\n", tempString);
    }
    break;

  case 3:
    if (decimalToTwosComplement(decimal, tempString))
    {
      printf("Overflow error: input is outside the range of an 8-bit signed integer.\n");
    }
    else
    {
      printf("The result is %s\n", tempString);
    }
    break;

  case 4:
    if (twosComplementToDecimal(decimal, tempString))
    {
      printf("Overflow error: input is outside the range of 2-digit hex or is not binary\n");
    }
    else
    {
      printf("The result is %s\n", tempString);
    }
    break;

  default:
    printf("Invalid choice\n");
  }
  return 0;
}
